var beforewidgetindashboardmenuAddItem = function(ev,args){
	'use strict';
	var title = "Blox Summary";
	if ( args.settings.name != "dashboard" ) 
		return;
	console.log(ev,args);
	var onChange = function(event) {
		var command = prism.$injector.get('$command');
		if (event.checked) {
			console.log("Add Blox Summary");
			var wb = prism.$injector.get("widget-new.services.widgetBuilder");
			var items = {}
			var widget = wb.getWidget(prism.activeDashboard.datasource, "BloX", prism.activeDashboard, items);
			widget.title = title;
			console.log(widget);
			var widgetList = [];
			prism.activeDashboard.widgets.$$widgets.forEach(widget => {
				widgetList.push({
					"title": widget.title,
					"value": widget.title
				})
			});


			widget.style =  {
				"currentCard": {
					"style": "",
					"script": "",
					"title": "",
					"showCarousel": false,
					"body": [
						{
							"type": "Container",
							"width": "90%",
							"style": {
								"margin": "0 auto"
							},
							"items": [
								{
									"type": "Container",
									"items": [
										{
											"type": "ColumnSet",
											"separator": false,
											"spacing": "default",
											"columns": [
												{
													"type": "Column",
													"items": [
														{
															"type": "TextBlock",
															"text": "Natural Language Generation",
															"weight": "medium",
															"size": "large",
															"wrap": true
														},
														{
															"type": "TextBlock",
															"text": "<br>Create an AI generated description of the data in your widget, or summarize the whole dashboard.<br>You can control the verbose and style of the output",
															"size": "small",
															"wrap": true
														},
													]
												},
												{
													"type": "Column",
													"items": [
														{
															"type": "Image",
															"height": "300px",
															"url": "branding/BloxAI/BloxAI.png",
															"horizontalAlignment": "center",
															"size": "stretch",
															"style": {
																"margin": "60px"
															}
														}
													]
												}
											]
										}
									]
								},
								{
									"type": "ColumnSet",
									"columns": [
										{
											"type": "Column",
											"spacing": "",
											"width": "50%",
											"id": "Widgets",
											"items": [
												{
													"type": "Container",
													"spacing": "none",
													"items": [
														{
															"type": "Input.ChoiceSet",
															"id": "WidgetList",
															"class": "",
															"value": "ariel",
															"displayType": "compact",
															"choices": widgetList
														}
													]
												}
											]
										}
									]
								},
								{
									"type": "ActionSet",
									"actions": [
										{
											"type": "WidgetSummary",
											"title": "Widget Summary",
											"data": {
												"question": "",
												"table": ""
											}
										}
									]
								},
								{
									"type": "Column",
									"width": "10px",
									"items": []
								},
								{
									"type": "ActionSet",
									"actions": [
										{
											"type": "DashboardSummary",
											"title": "Dashboard Summary",
											"data": {
												"question": "",
												"table": ""
											}
										}
									]
								},
								{
									"type": "Container",
									"id": "outputContainer",
									"spacing": "extraLarge",
									"separator": true,
									"items": [
										{
											"spacing": "medium",
											"type": "TextBlock",
											"text": "Output",
											"color": "black"
										}
									]
								}
							]
						}
					]
				},
				"currentConfig": {
					"fontFamily": "Open Sans",
					"fontSizes": {
						"default": 16,
						"small": 14,
						"medium": 22,
						"large": 32,
						"extraLarge": 50
					},
					"fontWeights": {
						"default": 400,
						"light": 100,
						"bold": 800
					},
					"containerStyles": {
						"default": {
							"backgroundColor": "#ffffff",
							"foregroundColors": {
								"default": {
									"normal": "#3A4356"
								},
								"white": {
									"normal": "#ffffff"
								},
								"grey": {
									"normal": "#9EA2AB"
								},
								"orange": {
									"normal": "#f2B900"
								},
								"yellow": {
									"normal": "#ffcb05"
								},
								"black": {
									"normal": "#000000"
								},
								"lightGreen": {
									"normal": "#93c0c0"
								},
								"green": {
									"normal": "#2BCC7F"
								},
								"red": {
									"normal": "#FA5656"
								},
								"accent": {
									"normal": "#2E89FC"
								},
								"good": {
									"normal": "#54a254"
								},
								"warning": {
									"normal": "#e69500"
								},
								"attention": {
									"normal": "#cc3300"
								}
							}
						}
					},
					"imageSizes": {
						"default": 40,
						"small": 40,
						"medium": 80,
						"large": 120
					},
					"imageSet": {
						"imageSize": "medium",
						"maxImageHeight": 100
					},
					"actions": {
						"color": "",
						"backgroundColor": "",
						"maxActions": 5,
						"spacing": "large",
						"buttonSpacing": 20,
						"actionsOrientation": "horizontal",
						"actionAlignment": "left",
						"margin": "0",
						"showCard": {
							"actionMode": "inline",
							"inlineTopMargin": 16,
							"style": "default"
						}
					},
					"spacing": {
						"default": 5,
						"small": 5,
						"medium": 10,
						"large": 20,
						"extraLarge": 40,
						"padding": 0
					},
					"separator": {
						"lineThickness": 1,
						"lineColor": "#D8D8D8"
					},
					"factSet": {
						"title": {
							"size": "default",
							"color": "default",
							"weight": "bold",
							"warp": true
						},
						"value": {
							"size": "default",
							"color": "default",
							"weight": "default",
							"warp": true
						},
						"spacing": 20
					},
					"supportsInteractivity": true,
					"imageBaseUrl": "",
					"height": 684
				},
				"currentCardName": "default",
				"narration": {
					"enabled": false,
					"display": "above",
					"format": "bullets",
					"verbosity": "medium",
					"up_sentiment": "good",
					"aggregation": "sum",
					"labels": []
				}
			};
			command.execute('dashboard.commands.createNewWidget', { $scope: prism.$scope }, { widget: widget }).then(function () {
				var textwidget = wb.getWidget(prism.activeDashboard.datasource, "richtexteditor", prism.activeDashboard, {});
				if ( prism.activeDashboard.layout.columns.length == 1 ) {
    				prism.activeDashboard.layout.columns[0].cells.splice(0, 0, prism.activeDashboard.layout.columns[0].cells.pop());
    				prism.activeDashboard.$dashboard.updateDashboard(prism.activeDashboard, "layout");
    				textwidget.title = "Text " + title
    				var layout = { column: 0 , cell: 0 , subcell: 1,  width: 200, height: 800};
    				command.execute('dashboard.commands.createNewWidget', { $scope: prism.$scope }, { widget: textwidget , layout: layout });
				} else {
    				prism.activeDashboard.layout.columns[0].cells.splice(0, 0, prism.activeDashboard.layout.columns[0].cells.pop());
    				prism.activeDashboard.$dashboard.updateDashboard(prism.activeDashboard, "layout");
    				textwidget.title = "Text " + title
    				command.execute('dashboard.commands.createNewWidget', { $scope: prism.$scope }, { widget: textwidget }).then(function () {
        				prism.activeDashboard.layout.columns[1].cells.splice(0, 0, prism.activeDashboard.layout.columns[0].cells.pop());
        				window.prism.activeDashboard.layout.columns[1].cells[0].subcells[0].elements[0].height = window.prism.activeDashboard.layout.columns[0].cells[0].subcells[0].elements[0].height;
        				prism.activeDashboard.$dashboard.updateDashboard(prism.activeDashboard, "layout");
    				});
				}
			});
		} else {
			console.log("Remove Blox Summary");
			var deletewidgets = []
			prism.activeDashboard.widgets.$$widgets.forEach(widget => { 
				if (widget.title == title || widget.title == ("Text " + title)) {
					deletewidgets.push(widget)
				}
			});
			// Sorry for the ugly code this is the only way it worked
			if (deletewidgets.length == 2 ) {
			    widget = deletewidgets[0];
                prism.activeDashboard.$dashboard.deleteWidget(widget).then(function () {
    			    prism.activeDashboard.layout.$$remove(widget);
    			    prism.activeDashboard.widgets.$$remove(widget);
    			    widget.destroy();
				}).then(function () {
    			    widget = deletewidgets[1];
                    prism.activeDashboard.$dashboard.deleteWidget(widget).then(function () {
        			    prism.activeDashboard.layout.$$remove(widget);
        			    prism.activeDashboard.widgets.$$remove(widget);
        			    widget.destroy();
                    });
				});
			} else {
    			deletewidgets.forEach(widget => {
    				console.log("call delete on " , widget );
    				console.log("scope", prism.$scope );
    				prism.activeDashboard.$dashboard.deleteWidget(widget).then(function () {
    				    prism.activeDashboard.layout.$$remove(widget);
    				    prism.activeDashboard.widgets.$$remove(widget);
    				    widget.destroy();
    				});
    			});
			}			
			prism.activeDashboard.$dashboard.updateDashboard(prism.activeDashboard, "layout");
		}
	}
	var checked = false;
	prism.activeDashboard.widgets.$$widgets.forEach(widget => {
		if (widget.title == title) {
			checked = true;
		}
	});

	var scope = {dashboard:args.dashboard}, // initialize scope
		activity = prism.$injector.get('base.services.$activity'), // get activity service
		separator = {
			type: "check",
			caption: "BloxAI Summary",
			change: onChange,
			checked: checked,
		}; // initialize separator
	// add items to menu
	args.settings.items.push(
		separator
	);
};
prism.on("beforemenu",beforewidgetindashboardmenuAddItem);

